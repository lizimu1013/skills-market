---
name: demo-skill
description: 一个用于演示上传、详情页 Markdown 渲染和 ZIP 下载的本地 Skill。
---

# Demo Skill

这是一个内置示例，用来展示详情页会直接渲染上传包里的 `SKILL.md`。

## 使用场景

- 预览 Skill 的 Markdown 内容
- 展示文件资源管理器中的真实包结构
- 测试下载原始 ZIP 包

## 工作流

1. 打开详情页
2. 查看 `SKILL.md` 渲染结果
3. 点击 download 下载完整 ZIP

`agents/openai.yaml` 只是这个 demo 包里的示例配置文件。
